﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'eu', {
	copy: 'Copyright &copy; $1. Eskubide guztiak erreserbaturik.',
	dlgTitle: 'CKEditor(r)i buruz',
	help: '$1 aztertu laguntza jasotzeko.',
	moreInfo: 'Lizentziari buruzko informazioa gure webgunean:',
	title: 'CKEditor(r)i buruz',
	userGuide: 'CKEditor User\'s Guide'
} );

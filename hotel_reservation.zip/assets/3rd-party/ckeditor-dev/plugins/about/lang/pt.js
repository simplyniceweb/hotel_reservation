﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'pt', {
	copy: 'Direitos de Autor &copy; $1. Todos os direitos reservados.',
	dlgTitle: 'Sobre o CKEditor',
	help: 'Doar $1 para ajudar.',
	moreInfo: 'Para informação sobre o licenciamento, visite o nosso site da web:',
	title: 'Sobre o CKEditor',
	userGuide: 'CKEditor - Guia do Utilizador'
} );

<?php foreach($images as $img) { ?>	
<li><img src="<?=base_url()?>assets/images/rooms/<?=$img->file_name?>" class="img-responsive center-block" /></li>
<?php } ?>
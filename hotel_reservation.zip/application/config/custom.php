<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('ASSETS', __DIR__.'/../../assets/');
$config['website_name'] = 'Laiya Coco Grove';

// Currency
// Set the value to 0 if you don't want the money to be converted else set it as 1
$config['USD'] = 0;
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Global configuration for email
	$config = array(
		'protocol' => 'smtp',
		'smtp_host' => 'ssl://smtp.googlemail.com',
		'smtp_port' => 465,
		'smtp_user' => 'cocogrovelaiya@gmail.com',
		'smtp_pass' => 'abbygale',
		'mailtype'  => 'html', 
		'charset'   => 'iso-8859-1'
	);

/* End of file email.php */
/* Location: ./application/config/email.php */